from . import MAGIC_core
from . import MAGIC

__version__ = "1.0.0"
